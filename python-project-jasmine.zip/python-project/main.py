# Input
tugas = int(input("Nilai tugas : "))
uts = int(input("Nilai UTS   : "))
uas = int(input("Nilai UAS   : "))
kehadiran = int(input("Kehadiran  : "))

nilai_akhir = (0.20 * tugas) + (0.30 * uts) + (0.50 * uas)

lulus = nilai_akhir >= 75 and kehadiran >= 80

predikat = nilai_akhir >= 85 and kehadiran >= 90 and nilai_akhir % 2 == 0

# Output
print("Nilai Akhir :", nilai_akhir)
if lulus and predikat:
    print("Status      : LULUS DENGAN PREDIKAT")
elif lulus:
    print("Status      : LULUS")
else:
    print("Status      : BELUM LULUS")
